# MachineLearning-tutorial-French
Codes provenant de mes vidéos YouTube : https://www.youtube.com/channel/UCmpptkXu8iIFe6kfDK5o7VQ
